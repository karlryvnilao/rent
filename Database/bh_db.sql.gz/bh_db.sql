-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2024 at 05:39 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bh_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bh_info`
--

CREATE TABLE `bh_info` (
  `bh_id` int(255) NOT NULL,
  `landlord_id` int(255) NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `landmark` varchar(255) NOT NULL,
  `no_rooms` varchar(255) NOT NULL DEFAULT '0',
  `license` varchar(255) NOT NULL,
  `description` varchar(500) NOT NULL,
  `bh_img` varchar(255) NOT NULL,
  `gmap_link` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `landlord_subscription`
--

CREATE TABLE `landlord_subscription` (
  `id` int(255) NOT NULL,
  `landlord_id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `start_date` datetime(6) DEFAULT NULL,
  `end_date` datetime(6) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `mode_of_payment` varchar(255) NOT NULL DEFAULT 'user',
  `receipt` varchar(255) NOT NULL,
  `denial_reason` varchar(255) NOT NULL DEFAULT 'no reason'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `owner_about`
--

CREATE TABLE `owner_about` (
  `landlord_id` int(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `birthdate` date NOT NULL,
  `landlord_image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `transaction_no` int(11) NOT NULL,
  `room_id` int(11) DEFAULT NULL,
  `tenant_id` int(11) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `amount_paid` varchar(255) DEFAULT NULL,
  `date_paid` varchar(50) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `room_info`
--

CREATE TABLE `room_info` (
  `room_id` int(11) NOT NULL,
  `bh_id` int(11) DEFAULT NULL,
  `room_no` varchar(255) DEFAULT NULL,
  `tenant_id` int(11) DEFAULT NULL,
  `room_status` text NOT NULL DEFAULT 'vacant',
  `price` varchar(50) NOT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `light` varchar(255) DEFAULT NULL,
  `outlet` varchar(255) DEFAULT NULL,
  `tables` varchar(255) DEFAULT NULL,
  `chair` varchar(255) DEFAULT NULL,
  `aircon` varchar(255) DEFAULT NULL,
  `electricfan` varchar(255) DEFAULT NULL,
  `room_description` varchar(255) DEFAULT NULL,
  `room_img_1` varchar(255) DEFAULT NULL,
  `room_img_2` varchar(255) DEFAULT NULL,
  `room_img_3` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tenant_about`
--

CREATE TABLE `tenant_about` (
  `tenant_id` int(11) NOT NULL,
  `bh_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `middlename` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `contact_no` varchar(15) DEFAULT NULL,
  `parents_contact` varchar(15) DEFAULT NULL,
  `tenant_image` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bh_info`
--
ALTER TABLE `bh_info`
  ADD PRIMARY KEY (`bh_id`),
  ADD UNIQUE KEY `owner_id` (`landlord_id`);

--
-- Indexes for table `landlord_subscription`
--
ALTER TABLE `landlord_subscription`
  ADD PRIMARY KEY (`id`),
  ADD KEY `landlord_id` (`landlord_id`);

--
-- Indexes for table `owner_about`
--
ALTER TABLE `owner_about`
  ADD UNIQUE KEY `landlord_id` (`landlord_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`transaction_no`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `tenant_id` (`tenant_id`);

--
-- Indexes for table `room_info`
--
ALTER TABLE `room_info`
  ADD PRIMARY KEY (`room_id`),
  ADD KEY `bh_id` (`bh_id`),
  ADD KEY `tenant_id` (`tenant_id`);

--
-- Indexes for table `tenant_about`
--
ALTER TABLE `tenant_about`
  ADD PRIMARY KEY (`tenant_id`),
  ADD KEY `bh_id` (`bh_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bh_info`
--
ALTER TABLE `bh_info`
  MODIFY `bh_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `landlord_subscription`
--
ALTER TABLE `landlord_subscription`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `transaction_no` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `room_info`
--
ALTER TABLE `room_info`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bh_info`
--
ALTER TABLE `bh_info`
  ADD CONSTRAINT `bh_info_ibfk_1` FOREIGN KEY (`landlord_id`) REFERENCES `owner_about` (`landlord_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `landlord_subscription`
--
ALTER TABLE `landlord_subscription`
  ADD CONSTRAINT `landlord_subscription_ibfk_1` FOREIGN KEY (`landlord_id`) REFERENCES `user_info` (`id`);

--
-- Constraints for table `owner_about`
--
ALTER TABLE `owner_about`
  ADD CONSTRAINT `owner_about_ibfk_1` FOREIGN KEY (`landlord_id`) REFERENCES `user_info` (`id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `room_info` (`room_id`),
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`tenant_id`) REFERENCES `tenant_about` (`tenant_id`);

--
-- Constraints for table `room_info`
--
ALTER TABLE `room_info`
  ADD CONSTRAINT `room_info_ibfk_1` FOREIGN KEY (`bh_id`) REFERENCES `bh_info` (`bh_id`),
  ADD CONSTRAINT `room_info_ibfk_2` FOREIGN KEY (`tenant_id`) REFERENCES `tenant_about` (`tenant_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tenant_about`
--
ALTER TABLE `tenant_about`
  ADD CONSTRAINT `tenant_about_ibfk_1` FOREIGN KEY (`bh_id`) REFERENCES `bh_info` (`bh_id`),
  ADD CONSTRAINT `tenant_about_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `room_info` (`room_id`),
  ADD CONSTRAINT `tenant_about_ibfk_3` FOREIGN KEY (`tenant_id`) REFERENCES `user_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
